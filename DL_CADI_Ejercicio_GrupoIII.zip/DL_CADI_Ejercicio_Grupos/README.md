# CADI Deep Learning – Ejercicio por grupos (Semanas 2 a 8)

Plantilla por equipos. Una carpeta por semana/actividad, con notebook + README.
Regla: comparaciones válidas (cambiar 1 variable a la vez).
Generado: 2026-03-27
