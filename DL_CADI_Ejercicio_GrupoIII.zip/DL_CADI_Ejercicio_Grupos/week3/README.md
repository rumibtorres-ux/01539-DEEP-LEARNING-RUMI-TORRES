week3: plantilla de entrega del equipo (notebook + README).
