week4_optimizacion: plantilla de entrega del equipo (notebook + README).
