week4_regularizacion: plantilla de entrega del equipo (notebook + README).
