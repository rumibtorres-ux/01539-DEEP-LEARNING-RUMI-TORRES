week5: plantilla de entrega del equipo (notebook + README).
