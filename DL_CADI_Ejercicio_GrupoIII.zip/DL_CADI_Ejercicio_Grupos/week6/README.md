week6: plantilla de entrega del equipo (notebook + README).
