week7: plantilla de entrega del equipo (notebook + README).
