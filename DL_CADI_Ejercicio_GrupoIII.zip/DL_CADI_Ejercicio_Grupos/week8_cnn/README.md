week8_cnn: plantilla de entrega del equipo (notebook + README).
